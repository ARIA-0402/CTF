release: The actual remote server runs with this configuration.
debug: The same driver is loaded but with debug configuration.
src: Source code of the driver.

Run `make debug` in `/debug` to compile a sample program.
